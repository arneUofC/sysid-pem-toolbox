# SYSID-PEM-TOOLBOX

System Identification and PEM Toolbox (SYSID-PEM-TOOLBOX).

## Installation
Clone the repository and install dependencies:
```bash
pip install -r requirements.txt
